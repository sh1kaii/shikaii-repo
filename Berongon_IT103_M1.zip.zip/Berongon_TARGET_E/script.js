
function addGap(gapHeight) {
    const gapElement = document.getElementById('gap');
    gapElement.style.height = gapHeight + 'px';  
}

addGap(80);  
